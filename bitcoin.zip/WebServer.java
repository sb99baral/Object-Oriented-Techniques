/*If the customer chooses the file server this sub class prompts to
 select between  the number and brand of GPUs*/
public class WebServer extends Server {
  private int additional;
   public static final int MAX_USERS = 128;
   
   public int getAdditional() {return additional; }//Accessor
   
   public void setAdditional(int s) { //Mutator

      if (s <0 || s > MAX_USERS || !((s & 7) == 0)) {
         throw new IllegalArgumentException("Multiple of 8 and shouldnot be between 0 and " + MAX_USERS);
         }
         additional = s;
       }
    
 
    
    public double computeUsage() {// calculation and abstract method


      double d =(10 * (additional/8))+20;
      if (d >128 )  {
         throw new IllegalArgumentException("Cannot be " + MAX_USERS);
       }
      return d;
      }
      
      public String toString() {
         return super.toString() +"\n, Additional Memory: " + additional + "\n customer bill: $" +computeUsage();
         }
         
      public boolean equals (Object o) {// equals method
         if (o instanceof WebServer) {
            WebServer w = (WebServer) o;
            return w.getName().equals(this.getName());
            }
           return false;
           }
       
}

