 import javax.swing.*;
 import java.io.*;

 /* Sagun Baral
5/03/2020
/IT-206-204 (Spring 2020) 
/PROGRAMMING ASSIGNMENT 10
  
/*Description:this program keeps track of must include how many customers have VMs,
 total amount of all monthly fees collected, the average monthly fee collected per customer,
  how much memory and disk space and GPUs are used, and the number of customers who are Bitcoin miner. It then
  prints a roster that can be emailed to all staff 
*/
 public class Impl {

   private static int userId = 0;

  public static final int MAX_ITEMS = 1000;
  
   public static void main (String [] args) {
         Server[] servers = new Server[MAX_ITEMS];//: create an array of the apprpriate type
// declare an array of the apprpriate type

         int choice =0;
         do{
            choice = mainMenu(servers);
            } while (choice !=5);
         }
        
    public static int mainMenu(Server[] servers)  {    //the program will perform the task according to the user's choice.

      String message = "1) Add Server\n"; 
      message += "2) Display all server Information\n";// promps user option

      message += "3) Roster all server Information\n";
      message += "5) EXIT the program";
      
      int choice =0;
      do {
         try{
            choice= Integer.parseInt(JOptionPane.showInputDialog(message));
             if(choice > 5 || choice <1) {
               throw new IllegalArgumentException("Please enter a number between 1 and 5");
               }
               switch (choice) {
                  case 1: 
                     createServer(servers);
                     break;
                  case 2:
                      displayAll(servers);
                     break;
                   case 3:
                      rosterALL(servers);
                     case 5:
                       JOptionPane.showMessageDialog(null,"Thanks for using the program.");
            } 
            }catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a  number between 1 and 5");
            }catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            }
           }   while (choice  != 5);
           
            return choice;
            }
            
   
          
        
      public static void createServer(Server[] servers) {
            int numServers = Server.getNumServers();
            if(numServers + 1> MAX_ITEMS) {
               throw new IllegalArgumentException("Cannot create server");
              }
              
              Server newServer = null;
              
              //get the server name
              
             boolean done = false;
             String name = null;
             String email =null;
             String phone = null;
             boolean os = false;
             int userId ;
            while (!done) {
               try{ 
                    name = JOptionPane.showInputDialog("Name of Customer name:");
                    
                    email = JOptionPane.showInputDialog("Email address of the customer:");// get the values needed for the constructo
                    phone = JOptionPane.showInputDialog("phone number of the customer:");
                    os = JOP.getBooleanFromUser("Corporate discount:");
                   

                  
                        done = true;
                        } catch (IllegalArgumentException e) {
                           JOptionPane.showMessageDialog(null, e.getMessage());// handle exceptions potentially thrown by objects
                           }
                           
                       }
                       
                       Object[] possibleValues = { "File Server", "Web Server","Bitcoin"};
                         Object selectedValue = JOptionPane.showInputDialog(null,"Is this a file server or web server",
                                                name, JOptionPane.INFORMATION_MESSAGE, null,
                                                possibleValues,possibleValues[0]);
                       if (selectedValue ==null) {
                        throw new IllegalArgumentException("Aborted");
                        } 
                         
                       if (selectedValue.equals("File Server")) {
                       newServer = new FileServer();
                       } else if (selectedValue.equals("Web Server")) {
       
                        newServer = new WebServer();
                        }
                        else newServer = new Bitcoin();

                        newServer.setName(name);
                        newServer.setEmail(email);
                        newServer.setPhone(phone);
                        newServer.setOs(os);
                        
                         
                           
                           
                          if (newServer instanceof FileServer) {
                              done = false;
                              while (!done) {
                              try{
                              // have to downcast to
                              FileServer fs = (FileServer) newServer;
                              fs.setBlockStorage(JOP.getStringFromUser("Block or object storage:"));
                              fs.setSsd(JOP.getStringFromUser("Magnetic or SSD storage:"));
                              fs.setStorage(Integer.parseInt(JOptionPane.showInputDialog("storage in terabytes:")));
                                done = true;

                             } catch(IllegalArgumentException nfe) {
                                 JOptionPane.showMessageDialog(null,"invalid input");
                                 } 

                                
                             }
                           } else if (newServer instanceof WebServer) {
                                done = false;
                              while (!done) {
                              try {
                              // have to downcast to
                              WebServer ws = (WebServer) newServer;
                             ws.setAdditional(Integer.parseInt(JOptionPane.showInputDialog("Additional Memory required:")));
                              done = true;
                              } catch(IllegalArgumentException nfe) {
                                 JOptionPane.showMessageDialog(null,"Must enter a valid number and Multiple of 8");
                                 } 
                                
                             }

                     }
                   else if (newServer instanceof Bitcoin) {
                     done = false;
                              while (!done) {
                              
                              // have to downcast to
                              Bitcoin bs = (Bitcoin) newServer;
                              bs.setNvdia(JOP.getStringFromUser("brand:AMD or NVIDIA:"));
                             bs.setGpu(Integer.parseInt(JOptionPane.showInputDialog("number of GPU :")));

                              done = true;
                                
                             }
                    
                         
                             
                             }
                     
                     //insert newServer 
                     
                    servers[numServers] = newServer;
                   
                   }
                   
                    
           public static  String createID()
{
    return String.valueOf(userId++);
}           
                 
                  
    public static void displayAll(Server [] servers) {

          double fsUsage =0;
          int fscount =0;
          double wsUsage =0;
         int wscount =0;
         double bsUsage =0;
         int bscount =0;       
        for(int i=0; i<Server.getNumServers();i++) {
           if (servers[i] instanceof WebServer) {
            wsUsage += servers[i].computeUsage();
            wscount++;}
            
           if (servers[i] instanceof FileServer) {
           fsUsage += servers[i].computeUsage();
           fscount++;
           }
            if (servers[i] instanceof Bitcoin) {
           bsUsage += servers[i].computeUsage();
           bscount++;
           }
           }
           
           if (fscount >0) {
           fsUsage /= fscount;
           }else{
            fsUsage = 0.0;
            }
            if (wscount >0) {
            wsUsage /= wscount;
            }else {
            wsUsage =0.0;
            }
             if (bscount >0) {
           bsUsage /= bscount;
           }else{
            bsUsage = 0.0;
            }
            
            
            
      int numServers = Server.getNumServers();
             if (numServers == 0) {
               throw new IllegalArgumentException("There aren't any servers.");
               
               }
               String results = "";
               for(int i=0; i<numServers;i++) {
           
                   results += "\n USER Id: " + 100+(userId++)+"\n";
                             
                  results += servers[i] +"\n";
                          }
                  results += "\n avg for all :" + ((fsUsage +wsUsage+bsUsage)/numServers)+"\n";

                
                

                  results += "\n TotalServers :" + numServers +"\n";
                        
                        


                  JOptionPane.showMessageDialog(null,results);
               }    
               
               
               
               
               
               
               
 public static void rosterALL(Server[] servers) {
       double fsUsage =0;
       int fscount =0;
       double wsUsage =0;
       int wscount =0;
       double bsUsage =0;  //generating roster
       int bscount =0;       
       for(int i=0; i<Server.getNumServers();i++) {
           if (servers[i] instanceof WebServer) {
            wsUsage += servers[i].computeUsage();
            wscount++;}
            
           if (servers[i] instanceof FileServer) {
           fsUsage += servers[i].computeUsage();
           fscount++;
           }
            if (servers[i] instanceof Bitcoin) {
           bsUsage += servers[i].computeUsage();
           bscount++;
           }
           }
           
           if (fscount >0) {
           fsUsage /= fscount;
           }else{
            fsUsage = 0.0;
            }
            if (wscount >0) {
            wsUsage /= wscount;
            }else {
            wsUsage =0.0;
            }
             if (bscount >0) {
           bsUsage /= bscount;
           }else{
            bsUsage = 0.0;
            }
            try{
             PrintWriter pw = new PrintWriter("roster.txt");
            
              pw.println((" total for file server: $:") + fscount +"\n");
              pw.println((" total for Web server: $:") + wscount +"\n");
              pw.println((" total for Bitcoin: $:") + bscount +"\n");
              pw.println(("Average File Service Price:") + fsUsage +"\n");
              pw.println(("Average Web Service Price:") + wsUsage +"\n");
              pw.println(("Average Bitcoin Price:") + bsUsage +"\n");
                      
             } catch(FileNotFoundException e) {
             JOptionPane.showMessageDialog(null, "file not found");
                }
                      }           
                           
 
                              
                                 
                            

                              
            }
            
           
           
           
           
           
          
           
      


         