public abstract class Server {
   private String name;
   private String phone;
   private String email;
   private boolean os;


   private static int numServers;
   
   public Server() {
      numServers++;
      }
   public String getName() { return name;  }//Accessor
   public String getEmail() { return email;  }
   public String getPhone() { return phone;  }
   public boolean getOs() {return os; }
   


   public static int getNumServers() {return numServers; }
   
   public void setName(String s) { //Mutator

      if(s == null || s.equals("")) {
         throw new IllegalArgumentException("Name cannot be blank");
         }
         name = s;
       }
        public void setEmail(String s) {
         String address =  "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";// validating users nput
      if(s == null || s.equals("") || !s.matches(address)) {
         throw new IllegalArgumentException("the format is xxxx@xxxx.xxx");
         }
         email = s;
       }
        public void setPhone(String s) {
         String vaidd =  "(\\D?[0-9]{3}\\D?)[0-9]{3}-[0-9]{4}" ;
      if(s == null || s.equals("") || !s.matches(vaidd)) {
         throw new IllegalArgumentException("the format is (xxx)xxx-xxxx");
         }
         phone = s;
       }
       
     
       
      public void setOs(boolean s) {
       
        os = s;
            }
    
       
       public abstract double computeUsage();//  abstract method
       
      
       
      public String toString() {
         return "\n Name: " + name + "\n email address:  "+ email + " \n phone number:  "+ phone + "\n Type:  " + getClass().getName()+ " \n Corporate Discount: "+ os ;
         
        }
        
       public boolean equals(Object o) {
         if( o instanceof Server) {
             Server s= (Server) o;
             return s.getName().equals(this.name);
             }
             return false;
           }
       }
           