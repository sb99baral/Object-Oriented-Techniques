/*If the customer chooses the file server this sub class prompts to
 select between  the number and brand of GPUs*/
public class Bitcoin extends Server {
   private String nvdia;
  private int gpu;
   public static final int MAX_USERS = 5000;
   
   public String nvdia() {return nvdia; }
   public int gpu() {return gpu; }
   
   
          public void setNvdia(String s) {
     if (s == null) throw new IllegalArgumentException();
        if (s.equals("")) throw new IllegalArgumentException();
        if (!(s.equalsIgnoreCase ("Nvidia") || s.equalsIgnoreCase("AMD")))throw new IllegalArgumentException(" has to be NVIDIA OR AMD");


                 nvdia = s;
       }
    
   
        public void setGpu(int t) {
      if (t <0 || t > MAX_USERS) {
         throw new IllegalArgumentException("Number of users should be between 0 and " + gpu);
         }
         gpu = t;
          
       }

    
    
    public double computeUsage() {
      double d = 0 ;
      if (nvdia.equalsIgnoreCase ("Nvidia"))  {
         d =(15*gpu)+ 20;
       }else{
       d = (10*gpu)+20;}
      return d;
      }
      
      public String toString() {
         return super.toString() +"\n Brand : " + nvdia+ "\n customer bill: $" +computeUsage();
         }
         
      public boolean equals (Object o) {
         if (o instanceof Bitcoin) {
            Bitcoin b = (Bitcoin) o;
            return b.getName().equals(this.getName());
            }
           return false;
           }
       }
            