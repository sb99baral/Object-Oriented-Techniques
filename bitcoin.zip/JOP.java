import javax.swing.JOptionPane;

public class JOP {

    public static void showMessage(String outputMessage) {
        JOptionPane.showMessageDialog(null, outputMessage);
    }

    public static String getStringFromUser(String userPrompt) {
        return JOptionPane.showInputDialog(userPrompt);
    }

    public static double getDoubleFromUser(String userPrompt) {
        String stringInput = "";
        while (true) {
            try {
                stringInput = getStringFromUser(userPrompt);
                double doubleInput = Double.parseDouble(stringInput);
                return doubleInput;
            } catch (NumberFormatException nfe) {
                showMessage("Invalid Input: " + stringInput);
            }
        }
    }

    public static int getIntFromUser(String userPrompt) {
        String stringInput = "";
        while (true) {
            try {
                stringInput = getStringFromUser(userPrompt);
                int intInput = Integer.parseInt(stringInput);
                return intInput;
            } catch (NumberFormatException nfe) {
                showMessage("Invalid Input: " + stringInput);
            }
        }
    }

    public static boolean getBooleanFromUser (String userPrompt) {
        int result = JOptionPane.showConfirmDialog(null, userPrompt,null,JOptionPane.YES_NO_OPTION);
        return (result == 0); // showConfirmDialog returns 0 for "yes" and 1 for "no"
    }

}
