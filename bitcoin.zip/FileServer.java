/*If the customer chooses the file server this sub class prompts to
 select between either block storage or object storage.They must also choose the 
 type of storage media of SSD or magnetic storage*/
public class FileServer extends Server {
   private String blockStorage;
   private String ssd;
   private int storage;

   public static final int MAX_USERS = 1024;
   
   public String blockStorage() {return blockStorage; }
   public String ssd() {return ssd; }

   
   
          public void setBlockStorage(String s) { //Mutator

     if (s == null) throw new IllegalArgumentException();
        if (s.equals("")) throw new IllegalArgumentException();
                if (!(s.equalsIgnoreCase ("block") || s.equalsIgnoreCase("object")))throw new IllegalArgumentException(" has to be block or object");

                 blockStorage = s;
       }
         public void setStorage(int t) {
      if (t <0 || t > MAX_USERS) {
         throw new IllegalArgumentException("Number of users should be between 0 and " + MAX_USERS);
         }
         storage = t;
       }
    
   
          public void setSsd(String s) {
     if (s == null) throw new IllegalArgumentException();
        if (s.equals("")) throw new IllegalArgumentException();
            if (!(s.equalsIgnoreCase ("SSD") || s.equalsIgnoreCase("magnetic")))throw new IllegalArgumentException(" has to be SSD or magnetic");

                 ssd = s;
       }

    
    
     public double computeUsage() { // calculation 
      double d = 0 ;
      if (ssd.equalsIgnoreCase ("SSD"))  {
         d =(5*storage)+ 20;
       }else{
       d = (2*storage)+20;}
      return d;
      }
      
      public String toString() {
         return super.toString() +"\n Storage : " + blockStorage +"  type of storage: "+ ssd +"\n customer bill: $" +computeUsage()  ;
         }
         
      public boolean equals (Object o) {
         if (o instanceof FileServer) {
            FileServer f = (FileServer) o;
            return f.getName().equals(this.getName());
            }
           return false;
           }
       }
            
      